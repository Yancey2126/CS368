#include <iostream>

class SmartInteger{
private:
  int num;

public:
  SmartInteger();
  SmartInteger(int num);
  int getValue() const;
  friend std::ostream& operator<<(std::ostream& os, const SmartInteger& rhs);
  bool operator<(const SmartInteger &other) const;
  bool operator>(const SmartInteger &other) const;
  bool operator<=(const SmartInteger &other) const;
  bool operator>=(const SmartInteger &other) const;
  bool operator==(const SmartInteger &other) const;
  bool operator!=(const SmartInteger &other) const;
  const SmartInteger operator+(const SmartInteger &rhs) const;
  const SmartInteger operator-(const SmartInteger &rhs) const;
  const SmartInteger operator*(const SmartInteger &rhs) const;
  SmartInteger & operator+=(const SmartInteger &rhs);
  SmartInteger & operator-=(const SmartInteger &rhs);
  SmartInteger & operator*=(const SmartInteger &rhs);
  SmartInteger &operator++();
  SmartInteger &operator--();
};
