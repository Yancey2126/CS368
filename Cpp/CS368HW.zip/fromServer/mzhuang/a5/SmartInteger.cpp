#include <iostream>
#include "SmartInteger.hpp"
#include <limits.h>

SmartInteger::SmartInteger() {
  num = 0;
}

SmartInteger::SmartInteger(int num) {
  this->num = num;
}

int SmartInteger::getValue() const {
  return num;
}

std::ostream& operator<<(std::ostream& os, const SmartInteger& rhs) {
    os << rhs.num;
    return os;
}

bool SmartInteger::operator<(const SmartInteger &other) const {
    return getValue() < other.getValue();
}

bool SmartInteger::operator>(const SmartInteger &other) const {
    return getValue() > other.getValue();
}

bool SmartInteger::operator<=(const SmartInteger &other) const {
    return getValue() <= other.getValue();
}

bool SmartInteger::operator>=(const SmartInteger &other) const {
    return getValue() >= other.getValue();
}

bool SmartInteger::operator==(const SmartInteger &other) const {
    return getValue() == other.getValue();
}

bool SmartInteger::operator!=(const SmartInteger &other) const {
    return getValue() != other.getValue();
}

const SmartInteger SmartInteger::operator+(const SmartInteger &rhs) const {
    if ((rhs.getValue() > 0) && (getValue() > INT_MAX - rhs.getValue())) throw std::exception();

    if ((rhs.getValue() < 0) && (getValue() < INT_MIN - rhs.getValue())) throw std::exception();

    else {
        SmartInteger result = (getValue() + rhs.getValue());
        return result;
    }
}

const SmartInteger SmartInteger::operator-(const SmartInteger &rhs) const {
    if ((rhs.getValue() < 0) && (getValue() > INT_MAX + rhs.getValue())) throw std::exception();

    if ((rhs.getValue() > 0) && (getValue() < INT_MIN + rhs.getValue())) throw std::exception();

    else{
        SmartInteger result = (getValue() - rhs.getValue());
        return result;
    }
}

const SmartInteger SmartInteger::operator*(const SmartInteger &rhs) const {

    if (getValue() > INT_MAX / rhs.getValue() && rhs.getValue() > 0) throw std::exception();
    else if (getValue() < INT_MIN / rhs.getValue() && rhs.getValue() > 0) throw std::exception();
    
   
    if (getValue() > INT_MIN / rhs.getValue() && rhs.getValue() < 0) throw std::exception();
    else if (getValue() < INT_MAX /rhs.getValue() && rhs.getValue() < 0) throw std::exception();
    
    else if ((getValue() == -1 ) && ( rhs.getValue() == INT_MIN)) throw std::exception();

    else if ((rhs.getValue() == -1) && (getValue() == INT_MIN)) throw std::exception();

    else{
        SmartInteger result(getValue() * rhs.getValue());
        return result;
    }
}

SmartInteger &SmartInteger::operator+=(const SmartInteger &rhs) {
    try{
        SmartInteger result = (*this  + rhs);
        num = result.getValue();
        return *this;
    }
    catch(std::exception e) {
        throw e;
    }
}

SmartInteger &SmartInteger::operator-=(const SmartInteger &rhs) {
    try{
        SmartInteger result = (*this - rhs);
        num = result.getValue();
        return *this;
    }
    catch(std::exception e) {
        throw e;
    }
}

SmartInteger &SmartInteger::operator*=(const SmartInteger &rhs) {
    try{
        SmartInteger result = (*this * rhs.getValue());
        num = result.getValue();
        return *this;
    }
    catch(std::exception e) {
        throw e;
    }
}

SmartInteger &SmartInteger::operator++() {
    try{
        SmartInteger result = (*this + 1);
        num = result.getValue();
        return *this;
    }
    catch(std::exception e) {
        throw e;
    }
}

SmartInteger &SmartInteger::operator--() {
    try{
        SmartInteger result = (*this - 1);
        num = result.getValue();
        return *this;
    }
    catch(std::exception e) {
        throw e;
    }
}
