////////////////////////////////////////////////////////////////////////////////
// File Name:      a1.cpp
//
// Author:         Miluo Zhuang
// CS email:       mzhuang4@wisc.edu
//
// Description:    A program that outputs information about myself
//                 and repeats a string.
//
// Sources:        None
//
// URL(s) of sources:
//                  none
////////////////////////////////////////////////////////////////////////////////

#include <iostream>
int numOfloop;
/**
 * @brief print repeated "-=-" as required
 * @param input The number of loops
 */
void foo(int input){
    if (input < 1){
        std::cout << std::endl;

    }
    for (int x = 0; x < input; x++) {
        std::cout << "-=-";
    }

}

int main() {
    //print personal info
    std::cout << "-+-+-+-+-+-+-+-+-+-+-+-+-" << std::endl;
    std::cout << "Name: Miluo Zhuang" << std::endl;
    std::cout << "Major: Economics" << std::endl;
    std::cout << "Year: Master" << std::endl;
    std::cout << "Reason I am taking this class: Let's build some wheels" << std::endl;
    std::cout << "-+-+-+-+-+-+-+-+-+-+-+-+-" << std::endl;
    std::cout << std::endl;

    //pass the initial number of loop to the variable numOfloop
    std::cout << "Number of times of loop: ";
    std::cin >> numOfloop;

    //call the foo function
    foo(numOfloop);

    return 0;
}
