////////////////////////////////////////////////////////////////////////////////
// File Name:      a3.cpp
//
// Author:         Gerald, Isaac, Varun
// CS email:       gerald@cs.wisc.edu
//                 cisung@wisc.edu
//                 vnaik@cs.wisc.edu
//
// Description:    The source file for a3.
//
// IMPORTANT NOTE: THIS IS THE ONLY FILE THAT YOU SHOULD MODIFY FOR A3.
//                 You SHOULD NOT MODIFY any of the following:
//                   1. Name of the functions.
//                   2. The number and type of parameters of the functions.
//                   3. Return type of the functions.
//                   4. Import statements.
//
// Sources:        <Sources, if any>
//
// URL(s) of sources:
//                 <URLs of your sources, if any>
////////////////////////////////////////////////////////////////////////////////

#include "a3.hpp"

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

void cleanData(std::istream &inFile, std::ostream &outFile,
               std::unordered_set<std::string> &commonWords) {
    // TODO: Implement this function.
    // Remember to call the helper functions below!
    std::string line;
    while(getline(inFile, line)) {
        std::vector<std::string> splitWords;
        splitLine(line, splitWords);
        removeCommonWords(splitWords, commonWords);
        for(int i = 0; i < splitWords.size(); ++i){
            outFile << splitWords[i] << ' ';
        }
        outFile << std::endl;
    }
}

void fillDictionary(std::istream &newInFile,
                    std::unordered_map<std::string, std::pair<long, long>> &dict) {
                        std::string line;
                        std::vector<std::vector<std::string>> metaWords;
                        while(getline(newInFile, line)) {
                            std::vector<std::string> splitWords;
                            splitLine(line, splitWords);
                            metaWords.push_back(splitWords);
                        }
                        for(int i = 0; i < metaWords.size(); ++i){
                            std::vector<std::string> tmp = metaWords[i];
                            for(int j = 1; j < tmp.size(); ++j){
                                auto it = dict.find(tmp[j]);
                                if(it == dict.end()){
                                    newInFile.clear();
                                    newInFile.seekg(0);
                                    std::string tokens;
                                    long count = 0;
                                    while(!newInFile.eof()){
                                        newInFile >> tokens;
                                        if(newInFile.eof()) break;
                                        if(tokens == tmp[j]){
                                            count ++;
                                        }
                                    }
                                    long rateNum = std::stol(tmp[0]);
                                    std::pair<long, long> foo(rateNum, count);
                                    dict.insert({tmp[j],foo});
                                }
                                else {
                                    long rateNum = std::stol(tmp[0]);
                                    it -> second.first += rateNum;
                                }
                            }
                        }
                    }

void fillCommonWords(std::istream &inFile,
                   std::unordered_set<std::string> &commonWords) {
    // TODO: Implement this function.
    std::string line;
    while(getline(inFile, line)) {
        commonWords.insert(line);
    }
}

void rateReviews(std::istream &testFile,
                 std::unordered_map<std::string, std::pair<long, long>> &dict,
                 std::ostream &ratingsFile) {
    // TODO: Implement this function.
    std::string line;
    while(getline(testFile, line)) {
        std::vector<std::string> splitWords;
        splitLine(line, splitWords);
        double sumScore = 0;
        double meanScore = 0;
        for (int i = 0; i < splitWords.size(); ++i) {
            auto it = dict.find(splitWords[i]);
            if(it != dict.end()) {
                meanScore = (double) it -> second.first / it -> second.second;
                sumScore += meanScore;
            }
            else {
                sumScore += 2.00;
            }
        }
        double rateScore = sumScore / splitWords.size();
        ratingsFile << std::fixed << std::setprecision(2) << rateScore << std::endl;
    }
}

void removeCommonWords(std::vector<std::string> &tokens,
                     std::unordered_set<std::string> &commonWords) {
    // TODO: Implement this function.
    tokens.erase(
        remove_if(
            tokens.begin(),
            tokens.end(),
            [&commonWords](const std::string& s){
                auto it = find(commonWords.begin(), commonWords.end(), s);
                return (it != commonWords.end());
            }
        ),
        tokens.end()
    );
}

void splitLine(std::string &line, std::vector<std::string> &words) {
    // This code is provided for you and is correct.
    // You should NOT make any changes to this function!
    std::stringstream ss;
    ss.str(line);
    std::string token;
    while (std::getline(ss, token, ' ')) {
        if (token.length() != 0) {
            words.push_back(token);
        }
    }
}
