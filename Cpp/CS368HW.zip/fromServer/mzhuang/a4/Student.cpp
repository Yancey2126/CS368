#include "Student.hpp"
#include "iostream"

int Student::numStudents = 0;

Student::Student(std::string name,
                 std::vector<double>
                 &assignmentsScore,
                 double projectScore):name(name), assignmentsScore(assignmentsScore),projectScore(projectScore) {
        id = numStudents;
        numStudents += 1;
    }

int Student::getId() {
    return id;
}

std::string Student::getName() {
    return name;
}

std::vector<double>& Student::getAssignmentsScore(){
    return assignmentsScore;
}

double Student::getProjectScore() {
    return projectScore;
}

int Student::getNumStudents() {
    return numStudents;
}

void Student::printDetails() {
    std::cout << "STUDENT DETAILS:" << std::endl;
    std::cout << "Id = " << getId() << std::endl;
    std::cout << "Name = " << getName() << std::endl;
    std::cout << "Assignments = [";
    std::vector<double>& tmp = getAssignmentsScore();
    for (auto it = tmp.begin(); it != tmp.end(); ++it) {
        if(it != tmp.begin()) std::cout << ", ";
        std::cout << *it;
    }
    std::cout << "]"<< std::endl;
    std::cout << "Project = " << getProjectScore() << std::endl;
    std::cout << "Total = " << getTotal() << std::endl;
    std::cout << "Grade = " << getGrade() << std::endl;
}
