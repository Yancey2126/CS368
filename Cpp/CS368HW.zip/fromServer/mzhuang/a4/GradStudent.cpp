#include "GradStudent.hpp"
#include "iostream"
#include "algorithm"

GradStudent::GradStudent(std::string name,
                         std::vector<double>& assignmentsScore,
                         double projectScore,
                         std::string researchArea,
                         std::string advisor):Student(name, assignmentsScore,
                         projectScore), researchArea(researchArea),
                         advisor(advisor) {

    }

std::string GradStudent::getResearchArea() {
    return researchArea;
}

std::string GradStudent::getAdvisor() {
    return advisor;
}

void GradStudent::printDetails() {
    Student::printDetails();
    std::cout << "Type = Graduate Student" << std::endl;
    std::cout << "Research Area = " << getResearchArea() << std::endl;
    std::cout << "Advisor = " << getAdvisor() << std::endl;
}

double GradStudent::getTotal() {
    std::vector<double> tmp = Student::getAssignmentsScore();

    double sumTmp = 0;

    std::for_each(tmp.begin(), tmp.end(), [&] (double n){
        sumTmp += n;
    });

    double avrTmp = sumTmp / tmp.size();

    double total = avrTmp * 0.5 + Student::getProjectScore() * 0.5;

    return total;
}

std::string GradStudent::getGrade() {
    std::string CR = "CR";
    std::string N = "N";
    if(getTotal() >= 80) return CR;
    else return N;
}
