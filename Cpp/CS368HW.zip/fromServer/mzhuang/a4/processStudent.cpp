///////////////////////////////////////////////////////////////////////////////
// File Name:      processStudent.cpp
//
// Author:         <your name>
// CS email:       <your CS email>
//
// Description:    Methods to perform some processing on student objects.
//
// Sources:        <Sources, if any>
//
// URL(s) of sources:
//                 <URLs of your sources, if any>
///////////////////////////////////////////////////////////////////////////////

#include "processStudent.hpp"
#include <sstream>
#include <algorithm>
#include <iostream>

// TODO: add other #include statements here, and using namespace std if desired
void splitLine(std::string &line, std::vector<std::string> &words);

std::vector<double> convertStringVectortoDoubleVector(const std::vector<std::string>& stringVector);

void fillStudents(std::istream &inFile,
                  std::vector<std::shared_ptr<Student>>& gstudentPtrs,
                  std::vector<std::shared_ptr<Student>>& ugstudentPtrs) {

    // TODO: Implement this method.
    std::string line;
    while (std::getline(inFile, line)) {
        std::vector<std::string> tmp;
        splitLine(line, tmp);
        if(tmp[0] == "G") {
            std::string name = tmp[1];
            std::vector<std::string> tmpAScore(tmp.begin()+2,tmp.end()-3);
            std::vector<double> assignmentsScore = convertStringVectortoDoubleVector(tmpAScore);
            double projectScore = std::stod(tmp[8]);
            std::string researchArea = tmp[9];
            std::string advisor = tmp[10];
            std::shared_ptr<Student> gPtr(new GradStudent(name, assignmentsScore, projectScore, researchArea, advisor));
            gstudentPtrs.push_back(gPtr);
        }
        else {
            std::string name = tmp[1];
            std::vector<std::string> tmpAScore(tmp.begin()+2, tmp.end()-3);
            std::vector<double> assignmentsScore = convertStringVectortoDoubleVector(tmpAScore);
            double projectScore = std::stod(tmp[8]);
            std::string residenceHall = tmp[9];
            std::string yearInCollege = tmp[10];
            std::shared_ptr<Student> uPtr(new UndergradStudent(name, assignmentsScore, projectScore, residenceHall, yearInCollege));
            ugstudentPtrs.push_back(uPtr);
        }
    }
}

void printStudents(std::vector<std::shared_ptr<Student>>& students) {

    // TODO: Implement this method.
    for(auto ptr : students){
        ptr -> printDetails();
        std::cout << std::endl;
    }
}

void computeStatistics(std::vector<std::shared_ptr<Student>>& students) {

    // TODO: Implement this method.

    // display the number of students (undergrad or grad)
    std::cout << "Number of students = " << students.size() << std::endl;
    // compute the mean of the total score.
    double sumTotal = 0;
    for (auto ptr : students){
        sumTotal += ptr -> getTotal();

    }

    double averTotal = sumTotal / students.size();
    std::cout << "The mean of the total score = " << averTotal << std::endl;
    // sort and print the students based on their total.
    sort(students.begin(), students.end(),
        [](const std::shared_ptr<Student> & lhs, const std::shared_ptr<Student> & rhs) -> bool {
        return (rhs->getTotal() < lhs->getTotal());
    });
    std::cout << "The sorted list of students (id, name, total, grade) in descending order of total:" << std::endl;
    for (auto ptr : students) {
        std::cout << ptr -> getId() << ", "
        << ptr -> getName() << ", "
        << ptr -> getTotal() << ", "
        << ptr -> getGrade() << std::endl;
    }
    std::cout << std::endl;
}

/**
 * @brief split a comma-separated string into a vector of strings with delimiter ",".
 * @param line a buffered line read from a text file.
 * @param words the output vector
 */
void splitLine(std::string &line, std::vector<std::string> &words) {
    // This code is provided for you and is correct.
    // You should NOT make any changes to this function!
    std::stringstream ss;
    ss.str(line);
    std::string token;
    while (std::getline(ss, token, ',')) {
        if (token.length() != 0) {
            words.push_back(token);
        }
    }
}

/**
 * @brief convert a vector of strings to a vector of doubles without exception-caring.
 * @param stringVector the vector of string to convert.
 */
std::vector<double> convertStringVectortoDoubleVector(const std::vector<std::string>& stringVector) {
    std::vector<double> doubleVector(stringVector.size());
    std::transform(stringVector.begin(), stringVector.end(),
    doubleVector.begin(), [](const std::string& val) {
                     return stod(val);
                 });
    return doubleVector;
}
