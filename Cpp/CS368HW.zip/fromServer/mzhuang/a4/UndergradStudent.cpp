#include "UndergradStudent.hpp"
#include "iostream"
#include "algorithm"


UndergradStudent::UndergradStudent(std::string name,
                                   std::vector<double> &assignmentsScore,
                                   double projectScore,
                                   std::string residenceHall,
                                   std::string yearInCollege):Student(name, assignmentsScore, projectScore),residenceHall(residenceHall),
                                           yearInCollege(yearInCollege) {
    }

std::string UndergradStudent::getResidenceHall() {
    return residenceHall;
}

std::string UndergradStudent::getYearInCollege() {
    return yearInCollege;
}

void UndergradStudent::printDetails() {
    Student::printDetails();
    std::cout << "Type = Undergraduate Student" << std::endl;
    std::cout << "Residence Hall = " << getResidenceHall() << std::endl;
    std::cout << "Year in College = " << getYearInCollege() << std::endl;
}

double UndergradStudent::getTotal() {
    std::vector<double> tmp = Student::getAssignmentsScore();

    double sumTmp = 0;

    std::for_each(tmp.begin(), tmp.end(), [&] (double n){
        sumTmp += n;
    });

    double avrTmp = sumTmp / tmp.size();

    double total = avrTmp * 0.7 + Student::getProjectScore() * 0.3;

    return total;
}

std::string UndergradStudent::getGrade() {
    std::string CR = "CR";
    std::string N = "N";
    if(getTotal() >= 70) return CR;
    else return N;
}
