///////////////////////////////////////////////////////////////////////
// File Name:      a2.cpp
//
// Author:         Miluo Zhuang
// CS email:       mzhuang4@wisc.edu
//
// Description:   Assignment 2
//
// Sources:
//
// URL(s) of sources:
///////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

//forward declaration.
bool readFile(const string &fileName, vector<string>& v);
bool writeFile(const string &fileName, vector<string> v);

int main(){

    bool first = false;
    vector<string> recipeBookOne;
    bool second = false;
    vector<string> recipeBookTwo;
    string firstFilename;
    string secondFilename;

    //Enter args of the first file through the console
    while (!first){
        cout << "Enter the name of the first file: ";
        cin >> firstFilename;
        if (readFile(firstFilename,recipeBookOne)) first = true;
        else {
            cout << "Input file ";
            cout << firstFilename;
            cout << " is NOT found. Please try again."<< endl;
        }
    }

    //Enter args of the second file through the console
    while (!second){
        cout << "Enter the name of the second file: ";
        cin >> secondFilename;
        if (readFile(secondFilename,recipeBookTwo)) second = true;
        else {
            cout << "Input file ";
            cout << secondFilename;
            cout << " is NOT found. Please try again."<< endl;
        }
    }
    cout << endl;
    vector<string> intcRecp;
    vector<string> uniRecp;

    //generate vectors of intersection and union of two recipes
    sort(recipeBookOne.begin(), recipeBookOne.end());
    sort(recipeBookTwo.begin(), recipeBookTwo.end());
    set_intersection(recipeBookOne.begin(), recipeBookOne.end(),
                        recipeBookTwo.begin(), recipeBookTwo.end(),
                        back_inserter(intcRecp)
                );

    set_union(recipeBookOne.begin(), recipeBookOne.end(),
                    recipeBookTwo.begin(), recipeBookTwo.end(),
                    back_inserter(uniRecp)
            );

    //print the summary info
    cout << "Number of recipes in ";
    cout << firstFilename;
    cout << " = ";
    cout << recipeBookOne.size() << endl;
    cout << "Number of recipes in ";
    cout << secondFilename;
    cout << " = ";
    cout << recipeBookTwo.size() << endl;
    cout << "Number of recipes that are present in BOTH ";
    cout << firstFilename;
    cout << " AND ";
    cout << secondFilename;
    cout << " = ";
    cout << intcRecp.size() << endl;
    cout << "Number of recipes that are in EITHER ";
    cout << firstFilename;
    cout << " OR ";
    cout << secondFilename;
    cout << " = ";
    cout << uniRecp.size() << endl;
    cout << endl;

    //print the intersection recipes
    if(!intcRecp.empty()){
            cout << "List of recipes that are present in BOTH ";
            cout << firstFilename;
            cout << " AND ";
            cout << secondFilename;
            cout << ":" << endl;
            for (auto it = intcRecp.begin(); it != intcRecp.end(); ++it){
                    cout << *it << endl;
            }
	    cout << endl;
    }


    //print the writeTo file success info
    if(writeFile("intersection.txt", intcRecp)) cout << "The set intersection of the two files was written to a file named intersection.txt" << endl;
    if(writeFile("union.txt", uniRecp)) cout << "The set union of the two files was written to a file named union.txt";
    return 0;
}
/**
 * Import the plain text file from the through the console
 * @param fileName
 * @param recipeBookName
 * @return
 */
bool readFile(const string &fileName, vector<string>& v){
    ifstream inFile(fileName.c_str());
    if(inFile.is_open()){
        string recipe;
        while(getline(inFile,recipe)){
            v.push_back(recipe);
        }
        return true;
    }
    return false;
}
/**
 * Create/Overwrite a file and wtire the text intio it.
 * @param filename
 * @param v
 * @return
 */
bool writeFile(const string &fileName, vector<string> v){
    ofstream outfile(fileName);
    for (auto it = v.begin(); it != v.end(); ++it){
        outfile << *it << endl;
    }
    return true;
}
